import React, { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import './Inspection.css';
import atomone from './image/atomone.jpg';

const PART_NAMES = ['INLET PIPE','OUTLET PIPE','BRACKET','COVER PLATE','BASE PLATE','FLANGE','HOUSING','SHAFT','GEAR','PULLEY','BUSHING','SPRING','WASHER','GASKET','CONNECTOR'];
const OPERATIONS = ['BLANKING','TURNING','MILLING','DRILLING','GRINDING','BORING','REAMING','THREADING','BROACHING','HOBBING','STAMPING','FORMING','BENDING','WELDING','ASSEMBLY','HEAT TREATMENT','SURFACE COATING','DEBURRING','POLISHING','FINAL INSPECTION'];
const CUSTOMER_NAMES = ['FIG','ATOM ONE','TATA MOTORS','MAHINDRA','MARUTI SUZUKI','HONDA','HYUNDAI','BAJAJ','TVS','HERO MOTOCORP','ASHOK LEYLAND','FORCE MOTORS','EICHER','PIAGGIO','YAMAHA'];

const formatDisplay = (dateStr) => {
  if (!dateStr) return '';
  const parts = String(dateStr).split('-');
  if (parts.length === 3) return `${parts[2]}/${parts[1]}/${parts[0]}`;
  return dateStr;
};

const Inspection = ({ items=[], currentReport, onFilter, onNewForm, onEditForm }) => {
  const navigate = useNavigate();

  if (currentReport?.date && !localStorage.getItem('headerDate')) {
    localStorage.setItem('headerDate', currentReport.date);
  }
  const displayDate = formatDisplay(localStorage.getItem('headerDate')) || '';

  const [showFilter,     setShowFilter]     = useState(false);
  const [filterDate,     setFilterDate]     = useState('');
  const [filterPart,     setFilterPart]     = useState('');
  const [filterOp,       setFilterOp]       = useState('');
  const [filterCustomer, setFilterCustomer] = useState('');
  const [judgments,      setJudgments]      = useState({});
  const [inspectedBy,    setInspectedBy]    = useState({});
  const [verifiedBy,     setVerifiedBy]     = useState({});

  // Refs for print sizing
  const reportRef = useRef(null);

  const scheduleEntries = currentReport?.schedule_entries || [];

  const productItems = items.filter(x=>x.sr_no>=1&&x.sr_no<=10).sort((a,b)=>a.sr_no-b.sr_no);
  const processItems = items.filter(x=>x.sr_no>=11&&x.sr_no<=20).sort((a,b)=>a.sr_no-b.sr_no);
  const productCount = productItems.filter(x=>x.item&&x.item.trim()!=='').length;
  const processCount = processItems.filter(x=>x.item&&x.item.trim()!=='').length;
  const totalRows    = 10;
  const totalFilledCols = Math.min(productCount+processCount, 14);

  const buildScheduleRows = () => {
    if (scheduleEntries.length === 0) {
      return [{
        sr:1, date:'', operator:'', mcNo:'',
        slots:[
          {time:'SETUP',row_order:0,values:Array(14).fill('')},
          {time:'SETUP',row_order:1,values:Array(14).fill('')},
          {time:'4HRS', row_order:0,values:Array(14).fill('')},
          {time:'4HRS', row_order:1,values:Array(14).fill('')},
          {time:'LAST', row_order:0,values:Array(14).fill('')},
          {time:'LAST', row_order:1,values:Array(14).fill('')},
        ]
      }];
    }

    const grouped = {};
    scheduleEntries.forEach(entry => {
      const sr = entry.sr || 1;
      if (!grouped[sr]) {
        grouped[sr] = { sr, date:formatDisplay(entry.date)||'', operator:entry.operator||'', mcNo:entry.machine_no||'', rawEntries:[] };
      }
      grouped[sr].rawEntries.push(entry);
    });

    return Object.values(grouped).map(grp => {
      const sorted = [...grp.rawEntries].sort((a,b)=>{
        const si = (a.slot_index??0)-(b.slot_index??0);
        if(si!==0) return si;
        return (a.row_order??0)-(b.row_order??0);
      });

      const slotMap = {};
      sorted.forEach(e=>{
        const si = e.slot_index??0;
        if(!slotMap[si]) slotMap[si]={ time_type:e.time_type, up:null, down:null };
        const vals = Array(14).fill('');
        for(let i=0;i<14;i++) vals[i]=e[`value_${i+1}`]||'';
        if(e.row_order===0) slotMap[si].up=vals;
        else                 slotMap[si].down=vals;
      });

      const slots = Object.values(slotMap).flatMap(s=>[
        {time:s.time_type, row_order:0, values:s.up   ||Array(14).fill('')},
        {time:s.time_type, row_order:1, values:s.down ||Array(14).fill('')},
      ]);

      return { sr:grp.sr, date:grp.date, operator:grp.operator, mcNo:grp.mcNo, slots };
    });
  };

  const scheduleRows = buildScheduleRows();
  // total HTML rows in schedule
  const totalSchedHtmlRows = scheduleRows.reduce((sum,s)=>sum+s.slots.length, 0);

  // ─────────────────────────────────────────────────────
  // onbeforeprint: measure actual screen element heights,
  // then scale everything to fit exactly in A4 landscape
  // ─────────────────────────────────────────────────────
  useEffect(()=>{
    const beforePrint = () => {
      const report = reportRef.current;
      if(!report) return;

      // Measure all children as rendered on screen
      const header   = report.querySelector('.header-table');
      const partInfo = report.querySelector('.fleet-info-table');
      const inspTbl  = report.querySelector('.inspection-table');
      const schedTbl = report.querySelector('.schedule-table');
      const footer   = report.querySelector('.footer');
      if(!header||!partInfo||!inspTbl||!schedTbl||!footer) return;

      // A4 landscape with 2mm margin = 206mm usable height in px at 96dpi
      const PAGE_H_PX = 206 * 3.7795;

      // Measure current screen heights
      const hH = header.offsetHeight;
      const pH = partInfo.offsetHeight;
      const iH = inspTbl.offsetHeight;
      const sH = schedTbl.offsetHeight;
      const fH = footer.offsetHeight;
      const totalScreenH = hH + pH + iH + sH + fH + 10; // 10px gaps

      // Scale factor: how much to compress to fit A4
      const scale = PAGE_H_PX / totalScreenH;

      // Apply scaled heights directly to DOM
      const setH = (el, h) => { el.style.height = Math.round(h)+'px'; el.style.overflow='hidden'; };

      setH(header,   hH * scale);
      setH(partInfo, pH * scale);
      setH(footer,   Math.max(fH * scale, 28)); // min 28px so footer always shows

      // Schedule: scale its rows
      const newSchedH = sH * scale;
      setH(schedTbl, newSchedH);
      const schedRowH = Math.floor(newSchedH / (totalSchedHtmlRows + 1));

      // Fixed cell texts — these must NOT be resized/overwritten
      const FIXED_TEXTS = new Set(['SR','DATE','OPERATOR','M/C NO','TIME','SETUP','4HRS','LAST','JDG','SIGN (INSPECTED BY)','SIGN (VERIFIED BY)']);

      schedTbl.querySelectorAll('tbody tr').forEach(tr=>{
        tr.style.height = schedRowH+'px';
        tr.querySelectorAll('td').forEach(td=>{
          const txt = (td.textContent||'').trim().toUpperCase();
          const isFixed = FIXED_TEXTS.has(txt) || td.rowSpan > 1;
          // Only resize height for all, but font/padding only for value cells
          td.style.height = schedRowH+'px';
          if(!isFixed){
            td.style.fontSize='8px';
            td.style.padding='0 2px';
          }
        });
      });
      schedTbl.querySelectorAll('thead th').forEach(th=>{ th.style.fontSize='8px'; th.style.padding='1px 2px'; });

      // Inspection: gets remaining space
      const usedH = (hH + pH + sH + Math.max(fH, 28/scale)) * scale + 10;
      const inspH = PAGE_H_PX - usedH;
      setH(inspTbl, Math.max(inspH, 80));
      const inspRowH = Math.floor((inspH - 20) / totalRows); // 20 for thead
      inspTbl.querySelectorAll('tbody tr').forEach(tr=>{
        tr.style.height = inspRowH+'px';
        tr.querySelectorAll('td').forEach(td=>{ td.style.height=inspRowH+'px'; td.style.fontSize='9px'; td.style.padding='0 2px'; });
      });
      inspTbl.querySelectorAll('thead th').forEach(th=>{ th.style.fontSize='8px'; th.style.padding='1px 3px'; });

      // Compact header fonts
      header.querySelectorAll('td').forEach(td=>{ td.style.fontSize='9px'; td.style.padding='1px 4px'; });
      const logo = header.querySelector('.logo-image');
      if(logo) logo.style.maxHeight='28px';
      const title = header.querySelector('.title-cell');
      if(title) title.style.fontSize='12px';

      partInfo.querySelectorAll('td').forEach(td=>{ td.style.fontSize='9px'; td.style.padding='1px 5px'; td.style.height=Math.round(pH*scale/2)+'px'; });

      // Footer always visible
      footer.style.height = Math.max(Math.round(fH*scale), 28)+'px';
      footer.style.display = 'flex';
      footer.style.alignItems = 'flex-end';
      footer.style.padding = '2px 8px';
      footer.querySelectorAll('label,input').forEach(el=>el.style.fontSize='9px');
    };

    const afterPrint = () => {
      // Reset ONLY beforePrint-added styles — do NOT removeAttribute
      // (removeAttribute wipes React JSX inline styles like rowSpan cells too)
      const report = reportRef.current;
      if(!report) return;

      const resetEl = (el) => {
        el.style.height    = '';
        el.style.overflow  = '';
        el.style.fontSize  = '';
        el.style.padding   = '';
        el.style.maxHeight = '';
      };

      const header   = report.querySelector('.header-table');
      const partInfo = report.querySelector('.fleet-info-table');
      const inspTbl  = report.querySelector('.inspection-table');
      const schedTbl = report.querySelector('.schedule-table');
      const footer   = report.querySelector('.footer');

      if(header)   { resetEl(header);   header.querySelectorAll('td,img').forEach(resetEl); }
      if(partInfo) { resetEl(partInfo); partInfo.querySelectorAll('td').forEach(resetEl); }
      if(inspTbl)  { resetEl(inspTbl);  inspTbl.querySelectorAll('th,td,tr').forEach(resetEl); }
      if(schedTbl) { resetEl(schedTbl); schedTbl.querySelectorAll('th,td,tr').forEach(resetEl); }
      if(footer)   {
        resetEl(footer);
        footer.style.display        = '';
        footer.style.alignItems     = '';
        footer.style.justifyContent = '';
        footer.querySelectorAll('label,input').forEach(resetEl);
      }
    };

    window.addEventListener('beforeprint', beforePrint);
    window.addEventListener('afterprint',  afterPrint);
    return ()=>{
      window.removeEventListener('beforeprint', beforePrint);
      window.removeEventListener('afterprint',  afterPrint);
    };
  }, [totalSchedHtmlRows, totalRows]);

  const isAnyFilterActive = filterDate||filterPart||filterOp||filterCustomer;
  const handleFilterApply = () => {
    if(!isAnyFilterActive){ alert('Please select at least one filter.'); return; }
    if(onFilter) onFilter({date:filterDate,partName:filterPart,operation:filterOp,customerName:filterCustomer});
    setShowFilter(false);
  };
  const handleFilterReset = () => {
    setFilterDate(''); setFilterPart(''); setFilterOp(''); setFilterCustomer('');
    localStorage.removeItem('headerDate');
    setShowFilter(false);
  };

  return (
    <div className="inspection-container">

      {/* ── Top Bar ── */}
      <div className="no-print" style={{display:'flex',justifyContent:'flex-end',alignItems:'center',gap:'12px',marginBottom:'10px'}}>
        <div style={{position:'relative'}}>
          <button onClick={()=>setShowFilter(p=>!p)} style={{
            background:showFilter?'#1565c0':'#1976d2',color:'#fff',border:'none',
            padding:'8px 20px',borderRadius:'6px',fontWeight:'bold',cursor:'pointer',fontSize:'14px',
            boxShadow:showFilter?'0 2px 8px rgba(25,118,210,0.4)':'none'
          }}>🔍 Filter {isAnyFilterActive?'●':''}</button>

          {showFilter&&(
            <>
              <div onClick={()=>setShowFilter(false)} style={{position:'fixed',inset:0,zIndex:998}}/>
              <div style={{position:'absolute',right:0,top:'46px',zIndex:999,background:'#fff',border:'1px solid #e0e0e0',borderRadius:'12px',boxShadow:'0 8px 32px rgba(0,0,0,0.18)',padding:'20px',minWidth:'320px'}}>
                <div style={{fontWeight:'bold',fontSize:'14px',marginBottom:'16px',color:'#1976d2',borderBottom:'2px solid #e3f2fd',paddingBottom:'10px',display:'flex',justifyContent:'space-between',alignItems:'center'}}>
                  <span>🔍 Filter Reports</span>
                  <span onClick={()=>setShowFilter(false)} style={{cursor:'pointer',color:'#999',fontSize:'16px'}}>✕</span>
                </div>
                <div style={{marginBottom:'14px'}}>
                  <label style={{fontSize:'11px',fontWeight:'700',color:'#555',display:'block',marginBottom:'5px',textTransform:'uppercase',letterSpacing:'0.5px'}}>📅 Date</label>
                  <div style={{position:'relative',display:'flex',alignItems:'center',border:`1px solid ${filterDate?'#1976d2':'#ccc'}`,borderRadius:'6px',padding:'7px 10px',background:filterDate?'#e3f2fd':'#fff',cursor:'pointer'}}>
                    <span style={{fontSize:'13px',flex:1,color:filterDate?'#1976d2':'#999'}}>{filterDate?filterDate.split('-').reverse().join('/'):'Select Date'}</span>
                    <span style={{fontSize:'14px'}}>📅</span>
                    <input type="date" value={filterDate} onChange={e=>setFilterDate(e.target.value)} style={{position:'absolute',opacity:0,width:'100%',height:'100%',cursor:'pointer',top:0,left:0}}/>
                  </div>
                </div>
                <div style={{marginBottom:'14px'}}>
                  <label style={{fontSize:'11px',fontWeight:'700',color:'#555',display:'block',marginBottom:'5px',textTransform:'uppercase',letterSpacing:'0.5px'}}>🔩 Part Name</label>
                  <select value={filterPart} onChange={e=>setFilterPart(e.target.value)} style={{width:'100%',padding:'7px 10px',border:`1px solid ${filterPart?'#1976d2':'#ccc'}`,borderRadius:'6px',fontSize:'13px',background:filterPart?'#e3f2fd':'#fff',color:filterPart?'#1976d2':'#333'}}>
                    <option value="">All Parts</option>
                    {PART_NAMES.map(p=><option key={p} value={p}>{p}</option>)}
                  </select>
                </div>
                <div style={{marginBottom:'14px'}}>
                  <label style={{fontSize:'11px',fontWeight:'700',color:'#555',display:'block',marginBottom:'5px',textTransform:'uppercase',letterSpacing:'0.5px'}}>⚙️ Operation Name</label>
                  <select value={filterOp} onChange={e=>setFilterOp(e.target.value)} style={{width:'100%',padding:'7px 10px',border:`1px solid ${filterOp?'#1976d2':'#ccc'}`,borderRadius:'6px',fontSize:'13px',background:filterOp?'#e3f2fd':'#fff',color:filterOp?'#1976d2':'#333'}}>
                    <option value="">All Operations</option>
                    {OPERATIONS.map(op=><option key={op} value={op}>{op}</option>)}
                  </select>
                </div>
                <div style={{marginBottom:'18px'}}>
                  <label style={{fontSize:'11px',fontWeight:'700',color:'#555',display:'block',marginBottom:'5px',textTransform:'uppercase',letterSpacing:'0.5px'}}>🏭 Customer Name</label>
                  <select value={filterCustomer} onChange={e=>setFilterCustomer(e.target.value)} style={{width:'100%',padding:'7px 10px',border:`1px solid ${filterCustomer?'#1976d2':'#ccc'}`,borderRadius:'6px',fontSize:'13px',background:filterCustomer?'#e3f2fd':'#fff',color:filterCustomer?'#1976d2':'#333'}}>
                    <option value="">All Customers</option>
                    {CUSTOMER_NAMES.map(c=><option key={c} value={c}>{c}</option>)}
                  </select>
                </div>
                {isAnyFilterActive&&(
                  <div style={{background:'#f0f7ff',border:'1px solid #90caf9',borderRadius:'6px',padding:'8px 10px',marginBottom:'14px',fontSize:'11px',color:'#1565c0'}}>
                    <b>Active:</b>{' '}
                    {filterDate&&<span style={{marginRight:'6px'}}>📅 {filterDate.split('-').reverse().join('/')}</span>}
                    {filterPart&&<span style={{marginRight:'6px'}}>🔩 {filterPart}</span>}
                    {filterOp&&<span style={{marginRight:'6px'}}>⚙️ {filterOp}</span>}
                    {filterCustomer&&<span>🏭 {filterCustomer}</span>}
                  </div>
                )}
                <div style={{display:'flex',gap:'8px'}}>
                  <button onClick={handleFilterApply} style={{flex:1,background:'#1976d2',color:'#fff',border:'none',padding:'9px',borderRadius:'6px',fontWeight:'bold',cursor:'pointer',fontSize:'13px'}}>✅ Apply Filter</button>
                  <button onClick={handleFilterReset} style={{flex:1,background:'#fff',color:'#e53935',border:'1px solid #e53935',padding:'9px',borderRadius:'6px',fontWeight:'bold',cursor:'pointer',fontSize:'13px'}}>🔄 Reset</button>
                </div>
              </div>
            </>
          )}
        </div>
        <button onClick={()=>{ if(onEditForm) onEditForm(); navigate('/form'); }} style={{background:'#ff9800',color:'#fff',border:'none',padding:'8px 20px',borderRadius:'6px',fontWeight:'bold',cursor:'pointer',fontSize:'14px'}}>✏️ Edit</button>
        <button onClick={()=>{ if(onNewForm) onNewForm(); navigate('/form'); }} style={{background:'#4CAF50',color:'#fff',border:'none',padding:'8px 20px',borderRadius:'6px',fontWeight:'bold',cursor:'pointer',fontSize:'14px'}}>📋 New Form</button>
      </div>

      <div className="inspection-report" ref={reportRef}>

        {/* Header */}
        <table className="header-table">
          <tbody>
            <tr>
              <td className="logo-cell" rowSpan="3"><img src={atomone} alt="ATOM ONE Logo" className="logo-image"/></td>
              <td className="title-cell" rowSpan="3">SETUP &amp; PATROL INSPECTION REPORT</td>
              <td className="doc-label">DOC NO:</td>
              <td className="doc-value">{currentReport?.doc_no||'KGTL-QCL-01'}</td>
            </tr>
            <tr><td className="doc-label">REVISION NO:</td><td className="doc-value">{currentReport?.revision_no||'01'}</td></tr>
            <tr>
              <td className="doc-label">DATE:</td>
              <td className="doc-value"><span style={{fontSize:'13px',padding:'4px 8px',display:'block'}}>{displayDate||'DD/MM/YYYY'}</span></td>
            </tr>
          </tbody>
        </table>

        {/* Part Info */}
        <table className="fleet-info-table">
          <tbody>
            <tr>
              <td className="field-label">PART NAME</td>
              <td className="field-input">{currentReport?.part_name||''}</td>
              <td className="field-label">OPERATION NAME</td>
              <td className="field-input">{currentReport?.operation_name||''}</td>
            </tr>
            <tr>
              <td className="field-label">PART NUMBER</td>
              <td className="field-input">{currentReport?.part_number||''}</td>
              <td className="field-label">CUSTOMER NAME</td>
              <td className="field-input">{currentReport?.customer_name||''}</td>
            </tr>
          </tbody>
        </table>

        {/* Inspection Table — always 10 rows */}
        <table className="inspection-table">
          <thead>
            <tr>
              <th>SR. NO.</th><th>INSP. ITEM (PRODUCT)</th><th>SPEC.</th><th>TOLERANCE</th><th>INST.</th>
              <th>SR. NO.</th><th>INSP. ITEM (PROCESS)</th><th>SPEC.</th><th>TOLERANCE</th><th>INST.</th>
            </tr>
          </thead>
          <tbody>
            {Array.from({length:totalRows},(_,i)=>{
              const product=productItems[i]||null;
              const pSR=product?.item?.trim()?(i+1):'';
              const process=processItems[i]||null;
              const rSR=process?.item?.trim()?(productCount+i+1):'';
              return(
                <tr key={i}>
                  <td>{pSR}</td><td>{product?.item||''}</td><td>{product?.spec||''}</td><td>{product?.tolerance||''}</td><td>{product?.inst||''}</td>
                  <td>{rSR}</td><td>{process?.item||''}</td><td>{process?.spec||''}</td><td>{process?.tolerance||''}</td><td>{process?.inst||''}</td>
                </tr>
              );
            })}
          </tbody>
        </table>

        {/* Schedule Table */}
        {(()=>{
          // Fixed cols %: SR(2%) + DATE(7%) + OPERATOR(8%) + M/CNO(4%) + TIME(3.5%) + JDG(2.5%) + SIGN×2(7.5×2=15%) = 47.5%
          const FIXED_PCT = 47.5;
          const numColPct = ((100 - FIXED_PCT) / Math.max(totalFilledCols, 1)).toFixed(2) + '%';
          return (
            <table className="schedule-table" style={{tableLayout:'fixed',width:'100%'}}>
              <colgroup>
                <col style={{width:'2%'}}/>   {/* SR */}
                <col style={{width:'7%'}}/>   {/* DATE */}
                <col style={{width:'8%'}}/>   {/* OPERATOR */}
                <col style={{width:'4%'}}/>   {/* M/CNO */}
                <col style={{width:'3.5%'}}/> {/* TIME */}
                {Array.from({length:totalFilledCols},(_,i)=>(
                  <col key={i} style={{width:numColPct}}/>
                ))}
                <col style={{width:'2.5%'}}/>  {/* JDG */}
                <col style={{width:'7.5%'}}/> {/* SIGN INSPECTED */}
                <col style={{width:'7.5%'}}/> {/* SIGN VERIFIED */}
              </colgroup>
              <thead>
                <tr>
                  <th style={{overflow:'hidden'}}>SR</th>
                  <th style={{overflow:'hidden'}}>DATE</th>
                  <th style={{overflow:'hidden'}}>OPERATOR</th>
                  <th style={{overflow:'hidden'}}>M/C NO</th>
                  <th style={{overflow:'hidden'}}>TIME</th>
                  {Array.from({length:totalFilledCols},(_,i)=><th key={i}>{i+1}</th>)}
                  <th style={{overflow:'hidden'}}>JDG</th>
                  <th style={{overflow:'hidden',whiteSpace:'normal',lineHeight:'1.2'}}>SIGN (INSPECTED BY)</th>
                  <th style={{overflow:'hidden',whiteSpace:'normal',lineHeight:'1.2'}}>SIGN (VERIFIED BY)</th>
                </tr>
              </thead>
              <tbody>
                {scheduleRows.map((si, rowIdx)=>{
                  const totalTimeRows = si.slots.length;
                  return(
                    <React.Fragment key={rowIdx}>
                      {si.slots.map((row, timeIdx)=>{
                        const isUpRow   = row.row_order===0;
                        const isNewTime = timeIdx%2===0;
                        return(
                          <tr key={`${rowIdx}-${timeIdx}`} style={{borderBottom:!isUpRow?'1px solid black':'1px solid #ddd'}}>
                            {timeIdx===0&&(<td rowSpan={totalTimeRows} style={{textAlign:'center',fontWeight:'bold',verticalAlign:'middle',fontSize:'11px',background:'#fff',overflow:'hidden'}}>{si.sr}</td>)}
                            {timeIdx===0&&(<td rowSpan={totalTimeRows} style={{textAlign:'center',fontSize:'10px',verticalAlign:'middle',background:'#fff',overflow:'hidden',wordBreak:'break-all',whiteSpace:'normal',lineHeight:'1.3'}}>{si.date||''}</td>)}
                            {timeIdx===0&&(<td rowSpan={totalTimeRows} style={{textAlign:'center',fontSize:'10px',verticalAlign:'middle',background:'#fff',overflow:'hidden',wordBreak:'break-word',whiteSpace:'normal',lineHeight:'1.3'}}>{si.operator||''}</td>)}
                            {timeIdx===0&&(<td rowSpan={totalTimeRows} style={{textAlign:'center',fontSize:'10px',verticalAlign:'middle',background:'#fff',overflow:'hidden',whiteSpace:'normal',wordBreak:'break-all'}}>{si.mcNo||''}</td>)}
                            {isNewTime&&(
                              <td rowSpan={2} style={{textAlign:'center',fontWeight:'bold',fontSize:'10px',verticalAlign:'middle',background:'#fff',whiteSpace:'nowrap',borderRight:'1px solid black',letterSpacing:'0.5px',padding:'4px 4px',color:'#000'}}>
                                {row.time}
                              </td>
                            )}
                            {Array.from({length:totalFilledCols},(_,ci)=>{
                              const val=row.values[ci]||'';
                              return(<td key={ci} style={{textAlign:'center',fontSize:'11px',color:'#000',fontWeight:val?'600':'normal',background:'#fff'}}>{val}</td>);
                            })}
                            {timeIdx===0&&(
                              <td rowSpan={totalTimeRows} style={{textAlign:'center',verticalAlign:'middle'}}></td>
                            )}
                            {timeIdx===0&&(
                              <td rowSpan={totalTimeRows} style={{textAlign:'center',verticalAlign:'middle'}}></td>
                            )}
                            {timeIdx===0&&(
                              <td rowSpan={totalTimeRows} style={{textAlign:'center',verticalAlign:'middle'}}></td>
                            )}
                          </tr>
                        );
                      })}
                    </React.Fragment>
                  );
                })}
              </tbody>
            </table>
          );
        })()}

        {/* Footer */}
        <div className="footer">
          <div className="signature-field">
            <label>PREPARED BY:</label>
            <input type="text" readOnly value={currentReport?.prepared_by||''}/>
          </div>
          <div className="signature-field">
            <label>APPROVED BY:</label>
            <input type="text" readOnly value={currentReport?.approved_by||''}/>
          </div>
        </div>

      </div>
    </div>
  );
};

export default Inspection;