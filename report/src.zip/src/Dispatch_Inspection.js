import React, { useState, useEffect } from 'react';
import { getDropdownOptions } from './services/api';
import { useNavigate } from 'react-router-dom';
import './Dispatch_Inspection.css';
import atomone from './image/atomone.jpg';

const formatDisplay = (dateStr) => {
  if (!dateStr) return '';
  const parts = String(dateStr).split('-');
  if (parts.length === 3) return `${parts[2]}/${parts[1]}/${parts[0]}`;
  return dateStr;
};

// ── PDI Report Component ──
const Dispatch_Inspection = ({ items = [], currentReport, onFilter, onEditForm }) => {
  const navigate = useNavigate();

  const displayDate = formatDisplay(currentReport?.inspection_date) || '';

  const [showFilter,     setShowFilter]     = useState(false);
  const [filterDate,     setFilterDate]     = useState('');
  const [filterPart,     setFilterPart]     = useState('');
  const [filterCustomer, setFilterCustomer] = useState('');

  // DB se dropdown options
  const [dbOptions, setDbOptions] = useState({ customers: [], part_names: [] });
  useEffect(() => {
    getDropdownOptions()
      .then(data => setDbOptions(data))
      .catch(err => console.error('Filter options fetch failed:', err));
  }, []);

  // Items: sr_no 1-25 = inspection rows
  const inspItems = items
    .filter(x => x.sr_no >= 1 && x.sr_no <= 25)
    .sort((a, b) => a.sr_no - b.sr_no);

  const TOTAL_ROWS = 25;

  // ── Print layout heights (A4 portrait 6mm margin = ~1050px usable) ──
  const TOTAL_USABLE  = 860;
  const HEADER_H      = 68;
  const INFO_H        = 52;
  const INSP_THEAD_H  = 46;   // 2-row header
  const REMARKS_H     = 30;
  const FOOTER_H      = 50;
  const FIXED_H       = HEADER_H + INFO_H + INSP_THEAD_H + REMARKS_H + FOOTER_H + 10;
  const availForRows  = TOTAL_USABLE - FIXED_H;
  const inspRowH      = Math.max(16, availForRows / TOTAL_ROWS);

  // ── Filter ──
  const isAnyFilterActive = filterDate || filterPart || filterCustomer;

  const handleFilterApply = () => {
    if (!isAnyFilterActive) { alert('Please select at least one filter.'); return; }
    if (onFilter) onFilter({ date: filterDate, partName: filterPart, customerName: filterCustomer });
    setShowFilter(false);
  };

  const handleFilterReset = () => {
    setFilterDate(''); setFilterPart(''); setFilterCustomer('');
    setShowFilter(false);
  };

  return (
    <div className="di-container">

      {/* ── Top Bar (no-print) ── */}
      <div className="no-print" style={{ display: 'flex', justifyContent: 'flex-end', alignItems: 'center', gap: '12px', marginBottom: '10px' }}>

        <button onClick={() => navigate('/selection')}
          style={{ background: '#607d8b', color: '#fff', border: 'none', padding: '8px 20px', borderRadius: '6px', fontWeight: 'bold', cursor: 'pointer', fontSize: '14px', display: 'flex', alignItems: 'center', gap: '6px' }}>
          <i className="bi bi-arrow-left-circle-fill"></i> Back
        </button>

        {/* Filter Button */}
        <div style={{ position: 'relative' }}>
          <button onClick={() => setShowFilter(p => !p)}
            style={{ background: showFilter ? '#1565c0' : '#1976d2', color: '#fff', border: 'none', padding: '8px 20px', borderRadius: '6px', fontWeight: 'bold', cursor: 'pointer', fontSize: '14px', display: 'flex', alignItems: 'center', gap: '6px' }}>
            <i className="bi bi-funnel-fill"></i> Filter {isAnyFilterActive ? '●' : ''}
          </button>

          {showFilter && (
            <>
              <div onClick={() => setShowFilter(false)} style={{ position: 'fixed', inset: 0, zIndex: 998 }} />
              <div style={{ position: 'absolute', right: 0, top: '46px', zIndex: 999, background: '#fff', border: '1px solid #e0e0e0', borderRadius: '12px', boxShadow: '0 8px 32px rgba(0,0,0,0.18)', padding: '20px', minWidth: '320px' }}>
                <div style={{ fontWeight: 'bold', fontSize: '14px', marginBottom: '16px', color: '#1976d2', borderBottom: '2px solid #e3f2fd', paddingBottom: '10px', display: 'flex', justifyContent: 'space-between' }}>
                  <span><i className="bi bi-funnel-fill" style={{ marginRight: 6 }}></i>Filter Reports</span>
                  <span onClick={() => setShowFilter(false)} style={{ cursor: 'pointer', color: '#999' }}>✕</span>
                </div>

                {[
                  {
                    label: <><i className="bi bi-calendar3" style={{ marginRight: 5 }}></i>Date</>,
                    content: (
                      <div style={{ position: 'relative', display: 'flex', alignItems: 'center', border: `1px solid ${filterDate ? '#1976d2' : '#ccc'}`, borderRadius: '6px', padding: '7px 10px', background: filterDate ? '#e3f2fd' : '#fff', cursor: 'pointer' }}>
                        <span style={{ fontSize: '13px', flex: 1, color: filterDate ? '#1976d2' : '#999' }}>
                          {filterDate ? filterDate.split('-').reverse().join('/') : 'Select Date'}
                        </span>
                        <input type="date" value={filterDate} onChange={e => setFilterDate(e.target.value)}
                          style={{ position: 'absolute', opacity: 0, width: '100%', height: '100%', cursor: 'pointer', top: 0, left: 0 }} />
                        <i className="bi bi-calendar3"></i>
                      </div>
                    )
                  },
                  {
                    label: <><i className="bi bi-gear-fill" style={{ marginRight: 5 }}></i>Part Name</>,
                    content: (
                      <select value={filterPart} onChange={e => setFilterPart(e.target.value)}
                        style={{ width: '100%', padding: '7px 10px', border: `1px solid ${filterPart ? '#1976d2' : '#ccc'}`, borderRadius: '6px', fontSize: '13px' }}>
                        <option value="">All Parts</option>
                        {dbOptions.part_names.map(p => <option key={p} value={p}>{p}</option>)}
                      </select>
                    )
                  },
                  {
                    label: <><i className="bi bi-building" style={{ marginRight: 5 }}></i>Customer</>,
                    content: (
                      <select value={filterCustomer} onChange={e => setFilterCustomer(e.target.value)}
                        style={{ width: '100%', padding: '7px 10px', border: `1px solid ${filterCustomer ? '#1976d2' : '#ccc'}`, borderRadius: '6px', fontSize: '13px' }}>
                        <option value="">All Customers</option>
                        {dbOptions.customers.map(c => <option key={c} value={c}>{c}</option>)}
                      </select>
                    )
                  },
                ].map(({ label, content }, i) => (
                  <div key={i} style={{ marginBottom: '14px' }}>
                    <label style={{ fontSize: '11px', fontWeight: '700', color: '#555', display: 'block', marginBottom: '5px', textTransform: 'uppercase' }}>{label}</label>
                    {content}
                  </div>
                ))}

                <div style={{ display: 'flex', gap: '8px', marginTop: '4px' }}>
                  <button onClick={handleFilterApply}
                    style={{ flex: 1, background: '#1976d2', color: '#fff', border: 'none', padding: '9px', borderRadius: '6px', fontWeight: 'bold', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '6px' }}>
                    <i className="bi bi-check-circle-fill"></i> Apply
                  </button>
                  <button onClick={handleFilterReset}
                    style={{ flex: 1, background: '#fff', color: '#e53935', border: '1px solid #e53935', padding: '9px', borderRadius: '6px', fontWeight: 'bold', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '6px' }}>
                    <i className="bi bi-arrow-counterclockwise"></i> Reset
                  </button>
                </div>
              </div>
            </>
          )}
        </div>

        {/* Edit & Print buttons — only when data exists */}
        {currentReport?.customer_name && (
          <>
            <button onClick={() => { if (onEditForm) onEditForm(); navigate('/form?mode=edit'); }}
              style={{ background: '#ff9800', color: '#fff', border: 'none', padding: '8px 20px', borderRadius: '6px', fontWeight: 'bold', cursor: 'pointer', fontSize: '14px', display: 'flex', alignItems: 'center', gap: '6px' }}>
              <i className="bi bi-pencil-square"></i> Edit
            </button>
            <button onClick={() => window.print()}
              style={{ background: '#4CAF50', color: '#fff', border: 'none', padding: '8px 20px', borderRadius: '6px', fontWeight: 'bold', cursor: 'pointer', fontSize: '14px', display: 'flex', alignItems: 'center', gap: '6px' }}>
              <i className="bi bi-printer-fill"></i> Print
            </button>
          </>
        )}
      </div>

      {/* ════════════════════════════════
           PRINT REPORT
          ════════════════════════════════ */}
      <div className="di-report">

        {/* ── HEADER ── */}
        <table className="di-header-table">
          <tbody>
            <tr>
              {/* Logo */}
              <td className="di-logo-cell">
                <img src={atomone} alt="ATOM ONE" className="di-logo-image" />
              </td>
              {/* Title */}
              <td className="di-title-cell">PRE DISPATCH INSPECTION REPORT</td>
              {/* Page No */}
              <td className="di-pageno-cell">
                <table><tbody>
                  <tr>
                    <td className="di-pn-label">PAGE NO.</td>
                    <td className="di-pn-value">{currentReport?.page_no || '01 OF 01'}</td>
                  </tr>
                </tbody></table>
              </td>
            </tr>
          </tbody>
        </table>

        {/* ── INFO ROWS ── */}
        <table className="di-info-table">
          <tbody>
            {/* Row 1 */}
            <tr>
              <td className="di-info-label">SUPPLIER NAME :</td>
              <td className="di-info-value" colSpan={3}>{currentReport?.supplier_name || ''}</td>
              <td className="di-info-label">PART NO :</td>
              <td className="di-info-value" colSpan={2}>{currentReport?.part_no || ''}</td>
              <td className="di-info-label">INSPECTION DATE. :</td>
              <td className="di-info-value">{displayDate}</td>
              <td className="di-info-label">CUSTOMER NAME:-</td>
              <td className="di-info-value">{currentReport?.customer_name || ''}</td>
            </tr>
            {/* Row 2 */}
            <tr>
              <td className="di-info-label">PART NAME :</td>
              <td className="di-info-value" colSpan={5}>{currentReport?.part_name || ''}</td>
              <td className="di-info-label">INVOICE NO.:-</td>
              <td className="di-info-value" colSpan={2}>{currentReport?.invoice_no || ''}</td>
              <td className="di-info-label">LOT QTY. :</td>
              <td className="di-info-value">{currentReport?.lot_qty || ''}</td>
            </tr>
          </tbody>
        </table>

        {/* ── INSPECTION TABLE ── */}
        <table className="di-insp-table" style={{ height: `${(INSP_THEAD_H + TOTAL_ROWS * inspRowH)}px` }}>
          <thead>
            {/* Header Row 1 */}
            <tr style={{ height: '23px' }}>
              <th rowSpan={2} className="di-th-sr">SR.<br />No.</th>
              <th rowSpan={2} className="di-th-item">INSPECTION ITEMS</th>
              <th rowSpan={2} className="di-th-spec">DIMENSIONS/<br />SPEC</th>
              <th rowSpan={2} className="di-th-tol">TOLERANCE</th>
              <th rowSpan={2} className="di-th-method">INSPECTION<br />METHOD</th>
              <th colSpan={3} className="di-th-group">VENDOR OBSERVATIONS</th>
              <th colSpan={3} className="di-th-group">CUSTOMER OBSERVATION</th>
              <th rowSpan={2} className="di-th-remarks">REMARKS</th>
            </tr>
            {/* Header Row 2 */}
            <tr style={{ height: '23px' }}>
              <th className="di-th-obs">1</th>
              <th className="di-th-obs">2</th>
              <th className="di-th-judge">Judgement</th>
              <th className="di-th-obs">1</th>
              <th className="di-th-obs">2</th>
              <th className="di-th-judge">Judgement</th>
            </tr>
          </thead>
          <tbody>
            {Array.from({ length: TOTAL_ROWS }, (_, i) => {
              const row = inspItems[i] || null;
              const srNo = row?.item?.trim() ? (i + 1) : '';
              const isEven = i % 2 === 1;
              return (
                <tr key={i} style={{ height: `${inspRowH}px`, background: isEven ? '#fafafa' : '#fff' }}>
                  <td className="di-td-center" style={{ fontSize: '9px', fontWeight: 'bold' }}>{srNo}</td>
                  <td className="di-td-left" style={{ fontWeight: row?.item ? '600' : 'normal', fontSize: '9px', whiteSpace: 'pre-line' }}>
                    {row?.item || ''}
                  </td>
                  <td className="di-td-center" style={{ fontSize: '9px', whiteSpace: 'pre-line' }}>{row?.spec || ''}</td>
                  <td className="di-td-center" style={{ fontSize: '9px' }}>{row?.tolerance || ''}</td>
                  <td className="di-td-center" style={{ fontSize: '9px', whiteSpace: 'pre-line' }}>{row?.method || ''}</td>
                  {/* Vendor Obs 1, 2, Judgement */}
                  <td className="di-td-center" style={{ fontSize: '9px' }}>{row?.vendor_obs1 || ''}</td>
                  <td className="di-td-center" style={{ fontSize: '9px' }}>{row?.vendor_obs2 || ''}</td>
                  <td className="di-td-center" style={{ fontSize: '9px', fontWeight: row?.vendor_judge ? '700' : 'normal', color: row?.vendor_judge === 'OK' ? '#1a7c1a' : row?.vendor_judge === 'NG' ? '#c0392b' : 'inherit' }}>
                    {row?.vendor_judge || ''}
                  </td>
                  {/* Customer Obs 1, 2, Judgement */}
                  <td className="di-td-center" style={{ fontSize: '9px' }}>{row?.cust_obs1 || ''}</td>
                  <td className="di-td-center" style={{ fontSize: '9px' }}>{row?.cust_obs2 || ''}</td>
                  <td className="di-td-center" style={{ fontSize: '9px', fontWeight: row?.cust_judge ? '700' : 'normal', color: row?.cust_judge === 'OK' ? '#1a7c1a' : row?.cust_judge === 'NG' ? '#c0392b' : 'inherit' }}>
                    {row?.cust_judge || ''}
                  </td>
                  <td className="di-td-left" style={{ fontSize: '9px' }}>{row?.remarks || ''}</td>
                </tr>
              );
            })}
          </tbody>
        </table>

        {/* ── SUPPLIER REMARKS ── */}
        <table className="di-remarks-table">
          <tbody>
            <tr>
              <td className="di-remarks-cell">
                <span style={{ fontWeight: 'bold', fontSize: '10px' }}>Supplier Remarks:</span>
                <span style={{ marginLeft: '12px', fontSize: '10px' }}>{currentReport?.supplier_remarks || ''}</span>
              </td>
            </tr>
          </tbody>
        </table>

        {/* ── FOOTER ── */}
        <div className="di-footer">
          <div className="di-sign-block">
            <span className="di-sign-label">Inspected By:-</span>
            <span className="di-sign-line">{currentReport?.inspected_by || ''}</span>
          </div>
          <div className="di-sign-block">
            <span className="di-sign-label">Verified By :-</span>
            <span className="di-sign-line">{currentReport?.verified_by || ''}</span>
          </div>
          <div className="di-sign-block">
            <span className="di-sign-label">Approved By:-</span>
            <span className="di-sign-line">{currentReport?.approved_by || ''}</span>
          </div>
          <div className="di-doc-ref">AOT-F-QA-40</div>
        </div>

      </div>
    </div>
  );
};

export default Dispatch_Inspection;