from rest_framework import viewsets, status
from rest_framework.response import Response
from django.shortcuts import get_object_or_404
from .models import InspectionReport, InspectionItem, ScheduleEntry
from .serializers import (
    InspectionReportSerializer,
    InspectionReportCreateSerializer,
    InspectionItemSerializer,
    ScheduleEntrySerializer
)


class InspectionReportViewSet(viewsets.ModelViewSet):
    """
    ViewSet for InspectionReport CRUD operations.
    Supports filtering by date: GET /api/reports/?date=YYYY-MM-DD
    """
    queryset = InspectionReport.objects.all()

    def get_serializer_class(self):
        if self.action in ['create', 'update', 'partial_update']:
            return InspectionReportCreateSerializer
        return InspectionReportSerializer

    def get_queryset(self):
        queryset = InspectionReport.objects.all()
        date = self.request.query_params.get('date', None)
        if date:
            queryset = queryset.filter(date=date)
        return queryset

    def list(self, request):
        """GET /api/reports/ — List all reports (optionally filter by date)"""
        queryset = self.get_queryset()
        serializer = InspectionReportSerializer(queryset, many=True)
        return Response(serializer.data)

    def retrieve(self, request, pk=None):
        """GET /api/reports/{id}/ — Get single report with items + schedule_entries"""
        report = get_object_or_404(InspectionReport, pk=pk)
        serializer = InspectionReportSerializer(report)
        return Response(serializer.data)

    def create(self, request):
        """POST /api/reports/ — Create new report"""
        serializer = InspectionReportCreateSerializer(data=request.data)
        if serializer.is_valid():
            report = serializer.save()
            # Return full data using read serializer
            return Response(
                InspectionReportSerializer(report).data,
                status=status.HTTP_201_CREATED
            )
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def update(self, request, pk=None):
        """PUT /api/reports/{id}/ — Full update (replaces items + schedule_entries)"""
        report = get_object_or_404(InspectionReport, pk=pk)
        serializer = InspectionReportCreateSerializer(report, data=request.data)
        if serializer.is_valid():
            report = serializer.save()
            return Response(InspectionReportSerializer(report).data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def partial_update(self, request, pk=None):
        """PATCH /api/reports/{id}/ — Partial update"""
        report = get_object_or_404(InspectionReport, pk=pk)
        serializer = InspectionReportCreateSerializer(report, data=request.data, partial=True)
        if serializer.is_valid():
            report = serializer.save()
            return Response(InspectionReportSerializer(report).data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def destroy(self, request, pk=None):
        """DELETE /api/reports/{id}/"""
        report = get_object_or_404(InspectionReport, pk=pk)
        report.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)


class InspectionItemViewSet(viewsets.ModelViewSet):
    """ViewSet for individual InspectionItem CRUD"""
    queryset = InspectionItem.objects.all()
    serializer_class = InspectionItemSerializer

    def get_queryset(self):
        queryset = InspectionItem.objects.all()
        report_id = self.request.query_params.get('report_id', None)
        if report_id:
            queryset = queryset.filter(report_id=report_id)
        return queryset


class ScheduleEntryViewSet(viewsets.ModelViewSet):
    """
    ViewSet for ScheduleEntry — the last table in the inspection form.
    Filter by report: GET /api/schedule/?report_id=1
    """
    queryset = ScheduleEntry.objects.all()
    serializer_class = ScheduleEntrySerializer

    def get_queryset(self):
        queryset = ScheduleEntry.objects.all()
        report_id = self.request.query_params.get('report_id', None)
        if report_id:
            queryset = queryset.filter(report_id=report_id)
        return queryset