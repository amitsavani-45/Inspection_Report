from django.apps import AppConfig


class InspectionformConfig(AppConfig):
    name = 'inspectionform'
